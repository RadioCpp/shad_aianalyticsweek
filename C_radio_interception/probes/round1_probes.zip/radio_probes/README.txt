Radio probes: submit each NN/answers.csv once and write down the score.

 probe  flipped_2to0  pad  score_if_bit1  score_if_bit0
     1           576    5             17             16
     2           576    5             17             16
     3           576    5             17             16
     4           576    5             17             16
     5           576    5             17             16
     6           576    5             17             16
     7           576    5             17             16
     8           513    5             26             25
     9           512    6             26             25
    10           512    6             26             25
    11           129    4             81             80

Report the 11 scores; the wrong string is the station-2 answer whose code has bit NN set where the score equals score_if_bit1.