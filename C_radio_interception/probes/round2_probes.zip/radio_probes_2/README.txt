 probe                        what  flips  score_high  score_low                                                    meaning
     1                  E-test d=5      5          99         98                                                 99 => E<=1
     2                  E-test d=4      4          99         98                                                 99 => E<=2
     3                  E-test d=3      3          99         98                                                 99 => E<=3
     4 answers 2->alt, 576 strings    580          17         16 high => group contains a wrong answer (valid for E=1 or 2)
     5 answers 2->alt, 576 strings    580          17         16 high => group contains a wrong answer (valid for E=1 or 2)
     6 answers 1->alt, 588 strings    594          15         14 high => group contains a wrong answer (valid for E=1 or 2)
     7 answers 1->alt, 587 strings    587          16         15 high => group contains a wrong answer (valid for E=1 or 2)
     8 answers 0->alt, 587 strings    587          16         15 high => group contains a wrong answer (valid for E=1 or 2)
     9 answers 0->alt, 586 strings    587          16         15 high => group contains a wrong answer (valid for E=1 or 2)
